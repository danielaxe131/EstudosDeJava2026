package Controle_STC;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class Leitor_Arquivo {

	public List<RegisMel> lerDados(String caminho){

        List<RegisMel> dados = new ArrayList<>();

        try{

            BufferedReader reader = new BufferedReader(new FileReader(caminho));
            String linha;

            while((linha = reader.readLine()) != null){

                String[] partes = linha.split(",");

                String especie = partes[0];
                int mes = Integer.parseInt(partes[1]);
                double producao = Double.parseDouble(partes[2]);

                RegisMel registro = new RegisMel(especie, mes, producao);

                dados.add(registro);
            }

            reader.close();

        }catch(Exception e){
            System.out.println("Erro ao ler arquivo");
        }

        return dados;
    }

}