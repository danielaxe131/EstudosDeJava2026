package Controle_STC;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class Gerador_HTML {

public void gerar(String caminho, List<Double> dados,
                  double media, double mediana,
                  double moda, double variancia) throws IOException {

FileWriter writer = new FileWriter(caminho);

StringBuilder dadosJS = new StringBuilder();

for(int i = 0; i < dados.size(); i++){
    dadosJS.append(dados.get(i));
    if(i < dados.size()-1){
        dadosJS.append(",");
    }
}

StringBuilder linhasTabela = new StringBuilder();

for(Double d : dados){
    linhasTabela.append("<tr><td>").append(d).append("</td></tr>");
}

writer.write("""
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Relatório Estatístico</title>

<script src="https://www.gstatic.com/charts/loader.js"></script>

<style>
body{font-family:Arial;margin:30px;background:#f5f5f5;}
.card{background:white;padding:15px;margin:10px;border-radius:10px;}
.valor{font-size:22px;font-weight:bold;}
#grafico{width:100%%;height:400px;}
</style>

<script>

google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {

var dados = [%s];

var tabela = new google.visualization.DataTable();
tabela.addColumn('number','valor');

for(let i=0;i<dados.length;i++){
    tabela.addRow([dados[i]]);
}

var options = {
title: 'Distribuição dos Dados'
};

var chart = new google.visualization.Histogram(document.getElementById('grafico'));
chart.draw(tabela, options);

}

</script>

</head>

<body>


<h1>Relatório Estatístico</h1>

<div class="card">
Media
<div class="valor">%.2f</div>
</div>

<div class="card">
Mediana
<div class="valor">%.2f</div>
</div>

<div class="card">
Moda
<div class="valor">%.2f</div>
</div>

<div class="card">
Variancia
<div class="valor">%.2f</div>
</div>


<h2>Dados de Produção</h2>

<table border="1" cellpadding="8">
<tr>
<th>Produção (g)</th>
</tr>

%s

</table>


<div id="grafico"></div>


</body>
</html>
""".formatted(
dadosJS.toString(),
media,
mediana,
moda,
variancia,
linhasTabela.toString()
));


writer.close();
}
}