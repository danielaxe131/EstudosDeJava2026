package Controle_STC;
import java.nio.file.*;
import java.io.IOException;
import java.util.*;
import java.util.stream.*;

public class Txt_repositorio {

    public List<Double> lerDados(String caminho) throws IOException {
	   return Files.lines(Paths.get(caminho))
	        .flatMap(l -> Arrays.stream(l.split(",")))
	        .map(Double::parseDouble)
	        .collect(Collectors.toList());
    	}
	}

