package Controle_STC;

import java.util.Collections;
import java.util.List;

public class Calcule_estatistica {

    public double media(List<Double> dados){

        double soma = 0;

        for(double d : dados){
            soma += d;
        }

        return soma / dados.size();
    }

    public double mediana(List<Double> dados){

        Collections.sort(dados);

        int n = dados.size();

        if(n % 2 == 0){
            return (dados.get(n/2 - 1) + dados.get(n/2)) / 2;
        }else{
            return dados.get(n/2);
        }
    }

    public double moda(List<Double> dados){

        double moda = dados.get(0);
        int maiorContagem = 0;

        for(double valor : dados){

            int contagem = 0;

            for(double v : dados){
                if(v == valor){
                    contagem++;
                }
            }

            if(contagem > maiorContagem){
                maiorContagem = contagem;
                moda = valor;
            }
        }

        return moda;
    }

    public double variancia(List<Double> dados){

        double media = media(dados);
        double soma = 0;

        for(double d : dados){
            soma += Math.pow(d - media, 2);
        }

        return soma / dados.size();
    }

}