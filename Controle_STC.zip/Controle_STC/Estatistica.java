package Controle_STC;

import java.util.List;
import java.util.ArrayList;

public class Estatistica {

    private List<Double> dados;
    private double media;
    private double moda;
    private double mediana;
    private double variancia;

    public void converterDados(List<RegisMel> registros){

        dados = new ArrayList<>();

        for(RegisMel r : registros){
            dados.add(r.getProducao());
        }

    }

    public List<Double> getDados() {
        return dados;
    }

    public void setDados(List<Double> dados) {
        this.dados = dados;
    }

    public double getMedia() {
        return media;
    }

    public void setMedia(double media) {
        this.media = media;
    }

    public double getModa() {
        return moda;
    }

    public void setModa(double moda) {
        this.moda = moda;
    }

    public double getMediana() {
        return mediana;
    }

    public void setMediana(double mediana) {
        this.mediana = mediana;
    }

    public double getVariancia() {
        return variancia;
    }

    public void setVariancia(double variancia) {
        this.variancia = variancia;
    }
}