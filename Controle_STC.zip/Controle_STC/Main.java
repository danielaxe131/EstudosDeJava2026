package Controle_STC;

import java.util.List;

public class Main {

    public static void main(String[] args) throws Exception {
    	
        Leitor_Arquivo leitor = new Leitor_Arquivo();

        String caminho = "C:\\Users\\Daniel\\Desktop\\dados.txt";
        String caminhoHtml = "C:\\Users\\Daniel\\Desktop\\resultado.html";

        if(Controle_Arquivo.jaFoiAberto(caminho)){
            System.out.println("Arquivo já foi aberto anteriormente.");
        }else{

            System.out.println("Abrindo arquivo...");

            List<RegisMel> registros = leitor.lerDados(caminho);

            Estatistica estat = new Estatistica();
            
            estat.converterDados(registros);
            
            for(RegisMel r : registros){
                System.out.println(r.getEspecie() + " - " + r.getMes() + " - " + r.getProducao());
            }
            System.out.println(estat.getDados());
            
            Calcule_estatistica calcule = new Calcule_estatistica();

            double media = calcule.media(estat.getDados());
            double mediana = calcule.mediana(estat.getDados());
            double moda = calcule.moda(estat.getDados());
            double variancia = calcule.variancia(estat.getDados());

            System.out.println("Media: " + media);
            System.out.println("Mediana: " + mediana);
            System.out.println("Moda: " + moda);
            System.out.println("Variancia: " + variancia);

            Gerador_HTML html = new Gerador_HTML();

            html.gerar(caminhoHtml, estat.getDados(), media, mediana, moda, variancia);

        }

    }
}