package Controle_STC;

public class RegisMel {
	private String especie;
    private int mes;
    private double producao;

    public RegisMel(String especie, int mes, double producao) {
        this.especie = especie;
        this.mes = mes;
        this.producao = producao;
    }

    public String getEspecie() { return especie; }
    public int getMes() { return mes; }
    public double getProducao() { return producao; }
}