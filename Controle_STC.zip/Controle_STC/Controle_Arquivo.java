package Controle_STC;

import java.util.HashSet;
import java.util.Set;

public class Controle_Arquivo {

    private static Set<String> arquivosAbertos = new HashSet<>();

    public static boolean jaFoiAberto(String caminho){

        if(arquivosAbertos.contains(caminho)){
            return true;
        }

        arquivosAbertos.add(caminho);
        return false;
    }
}
